package Ques7;

class Account {
    private String accountHolder;
    private long accountNumber;
    private double initialBalance;
}

public class BankApp {
    public static void main(String[] args){

    }
}
