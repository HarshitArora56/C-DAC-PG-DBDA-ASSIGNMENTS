package Polymorphism.CompileTime;

class CurrencyConverter {

}

public class Ques15 {
    public static void main(String[] args) {

    }
}
